--Insert 触发器
CREATE TRIGGER [core].[Trigger_Insert]
   ON  [core].[CL_TUOP20]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @PNID int set @PNID=0
	Declare @StationId int
	Declare @CurrentTime varchar(30)
	Declare @productSate int
	Declare @WorkOrderId bigint
	Declare @SerialNumber varchar(50)
	Declare @Rand varchar(10)
	Declare @State int  set @State=0

	--0-9之间随机数
	set @Rand=cast(floor(rand()*10) as varchar(10))
	--时间转字符串
    set @CurrentTime=CONVERT(varchar(11),GETDATE(),112)+REPLACE(CONVERT(varchar(12),GETDATE(),108),':','')
    --获取0P20的工件生产结果
	Select top 1 @productSate=CAST(DB48_DBD40 AS INT)  From [core].[CL_TUOP20] order by CREATE_DATE DESC
	--print @productSate

	--获取工站Id
	select @StationId=Id from core.Station where  StationNumber='TU_OP20'

	--获取工单Id
	select top 1  @WorkOrderId=[WorkOrderId] from [core].[CurrentActivedWorkOrderInformation]

	--不良品
	if(@productSate=2)
	begin
	   set @State=-2
	end

	--生成产品序列号
    set @SerialNumber='TU_'+@CurrentTime+@Rand
	insert into   [core].[PartSerialNumber]([MasterSerialNumber],[SerialNumber],[WorkOrderId],[CreationDateTime],[State])
	values(@SerialNumber,@SerialNumber,@WorkOrderId,GETDATE(),@State);
	set @PNID=SCOPE_IDENTITY();

	--1OK
	if (@productSate=1 and @PNID<>0)
	begin	
	  insert into [trace].[PartProcessRecord]([ProcessStepId],[PartSerialNumberId],[ProcessState],[StationId],[Layer],[ProductionDateTime],[BookDateTime],[CycleTime]) 
	  values(1118,@PNID,0,@StationId,0,GETDATE(),GETDATE(),0)
	end
	--2NG
	else if (@productSate=2 and @PNID<>0)
	begin
	    insert into [trace].[PartFailureDataRecord]([PartSerialNumberId],[SequenceNumber],[FailureTypeId],[FailureCauseId],[Layer],[Designator],
		[IsFalseReject],[IsCriticalFailure],[ProductionDateTime],[BookDateTime],[StationId]) 
		values(@PNID,1,1,1,0,'无',0,0,GETDATE(),GETDATE(),@StationId)
	end
END
go

