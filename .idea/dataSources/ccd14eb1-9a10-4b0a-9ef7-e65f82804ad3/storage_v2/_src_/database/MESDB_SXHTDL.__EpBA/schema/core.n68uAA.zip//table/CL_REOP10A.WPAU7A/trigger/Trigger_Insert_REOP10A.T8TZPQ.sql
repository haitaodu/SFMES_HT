-- =============================================
-- Author:	石霖	<Author,,Name>
-- Create date: <Create Date,,>
-- Description:CL_REOP10A过站记录	<Description,,>
-- =============================================
CREATE TRIGGER [core].[Trigger_Insert_REOP10A]
   ON  [core].[CL_REOP10A]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @PNID int set @PNID=0
	Declare @WorkOrderId bigint
    Declare @State int  set @State=0
	Declare @SerialNumberId int
	Declare @SerialNumber varchar(50)
	Declare @StationId int  --当前站
	Declare @Rand varchar(10)
	Declare @CurrentTime varchar(30)


	--0-9之间随机数
	set @Rand=cast(floor(rand()*10) as varchar(10))
	--时间转字符串
    set @CurrentTime=CONVERT(varchar(11),GETDATE(),112)+REPLACE(CONVERT(varchar(12),GETDATE(),108),':','')

    --获取0P80的二维码
	Select top 1 @SerialNumber=[SerialNumber] From [core].[CL_REOP10A] order by CREATE_DATE DESC

	--获取工单Id
	select top 1  @WorkOrderId=[WorkOrderId] from [core].[CurrentActivedWorkOrderInformation]

	--获取当前工站Id
	select @StationId=Id from core.Station where  StationNumber='RE_OP10A'

	--生成产品序列号
    set @SerialNumber='RE_'+@CurrentTime+'OP10A'+@Rand
	insert into   [core].[PartSerialNumber]([MasterSerialNumber],[SerialNumber],[WorkOrderId],[CreationDateTime],[State])
	values(@SerialNumber,@SerialNumber,@WorkOrderId,GETDATE(),@State);
	set @PNID=SCOPE_IDENTITY();

	if(@SerialNumber is not null)
	begin
	  select top 1 @SerialNumberId=Id from core.PartSerialNumber where SerialNumber=@SerialNumber
	end

	if(@SerialNumberId<>0)
	begin
	  insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
	  values(1015,@SerialNumberId,0,@StationId,0,GETDATE(),GETDATE(),0)
	end

	END
go

