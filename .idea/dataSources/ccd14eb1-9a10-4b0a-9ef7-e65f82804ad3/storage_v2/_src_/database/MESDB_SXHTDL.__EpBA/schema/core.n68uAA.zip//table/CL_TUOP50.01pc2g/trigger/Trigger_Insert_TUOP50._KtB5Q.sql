-- =============================================
-- Author:	石霖	<Author,,Name>
-- Create date: 2020-8-5<Create Date,,>
-- Description:	OP50进行虚拟条码替换<Description,,>
-- =============================================
CREATE TRIGGER [core].[Trigger_Insert_TUOP50]
   ON  [core].[CL_TUOP50]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;

 BEGIN TRAN Tran_Money    --开始事务

 --   DECLARE @tran_error int;SET @tran_error = 0;
	--Declare @PNID int
	--Declare @PreviousStation int --前一站
	--Declare @LastStationId int  --最后一站
	--Declare @StationId int  --当前站
	--Declare @WOderStartTime dateTime --工单开始时间
	--Declare @CurrentTime varchar(30)
	--Declare @productOKSate int
	--Declare @productNGSate int
	--Declare @WorkOrderId bigint
	--Declare @NewSerialNumber varchar(50)
	--Declare @OldSerialNumberId bigint
	--Declare @NewSerialNumberId bigint
	--set @NewSerialNumberId=0

 --   --获取工单信息
	--select top 1  @WorkOrderId=[WorkOrderId],@WOderStartTime=wo.ActualStartDateTime
	--from [core].[CurrentActivedWorkOrderInformation] awo
	--left join core.WorkOrder wo on awo.WorkOrderId=wo.Id

	----获取0P50的工件生产结果和二维码
	--Select top 1 @productOKSate=CAST([DB20_DBX60_1] AS INT),@productNGSate=CAST([DB20_DBX60_2] AS INT),@NewSerialNumber= DB10_DBX1104_0
	--From [core].[CL_TUOP50] order by CREATE_DATE DESC
 --   --打标机条码[DB10_DBX1104_0]
	----前一站记录
	--select @PreviousStation=Id from core.Station where  StationNumber='TU_OP40'
	----最后一站记录
	--select @LastStationId=Id from core.Station where  StationNumber='TU_OP45'
	----获取当前工站Id
	--select @StationId=Id from core.Station where  StationNumber='TU_OP50'

	----找到OP40未替换的条码
	--select top 1 @OldSerialNumberId=psn.Id from trace.PartProcessRecord ppr left join  core.PartSerialNumber psn  on ppr.PartSerialNumberId=psn.Id
	--where psn.WorkOrderId=@WorkOrderId and ppr.StationId=@PreviousStation and psn.SerialNumber like 'TU%' order by ppr.ProductionDateTime

	----替换条码信息
	--if(@OldSerialNumberId<>0 and @NewSerialNumber is not null)
	--begin try
	--   --先删除之前条码 
	--   delete core.PartSerialNumber where SerialNumber=@NewSerialNumber
	--   SET @tran_error = @tran_error + @@ERROR;
	--   --更新条码信息
	--   update core.PartSerialNumber set SerialNumber=@NewSerialNumber, MasterSerialNumber=@NewSerialNumber where Id=@OldSerialNumberId
	--   set @tran_error = @tran_error + @@ERROR;
	--end try
	--begin catch
	--	 print '出现异常，错误编号：' + convert(varchar,error_number()) + ',错误消息：' + error_message()
	--	 set @tran_error = @tran_error + 1
	--end catch
	----获取SN号
	----select top 1 @SerialNumberId=a.Id 
	----from (select sn.Id,sn.SerialNumber,sn.CreationDateTime from core.PartSerialNumber sn 
	----left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	----where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@LastStationId) a 
	----where a.Id not in (select sn.Id from core.PartSerialNumber sn 
	----left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	----where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@StationId)
	----order by a.CreationDateTime asc

	----print @SerialNumberId
	----print 'text'

	--select top 1 @NewSerialNumberId=Id from core.PartSerialNumber where SerialNumber=@NewSerialNumber

	----判断添加过站记录或异常信息1良品0不良品
	--if (@productOKSate=1 and @productNGSate=0 and @NewSerialNumberId<>0)
	--begin
	--	--找到过了OP45没有过OP50站的产品并插入到过站记录中
	--	insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
	--	values(1123,@NewSerialNumberId,0,@StationId,0,GETDATE(),GETDATE(),0)
	--end
	--else if(@productOKSate=0 and @productNGSate=1 and @NewSerialNumberId<>0)
	--begin
	--    insert into [trace].[PartFailureDataRecord]([PartSerialNumberId],[SequenceNumber],[FailureTypeId],[FailureCauseId],[Layer],[Designator],
	--	[IsFalseReject],[IsCriticalFailure],[ProductionDateTime],[BookDateTime],[StationId]) 
	--	values(@NewSerialNumberId,1,1,1,0,'无',0,0,GETDATE(),GETDATE(),@StationId)
	--end

	--if(@tran_error > 0)
 --   begin
 --       --执行出错，回滚事务
 --       ROLLBACK TRAN;
 --       print '删除之前条码/更新条码信息失败，取消删除和更新!';
 --   end
	--else
 --   begin
 --       --没有异常，提交事务
 --       COMMIT TRAN;
 --       print '删除和更新成功!';
 --   end
END
go

