Create PROCEDURE proctest
AS BEGIN 
BEGIN TRANSACTION; 
declare @i int
declare @j int
set @i = 19
set @j = 3
while @j <- 97
BEGIN 
 	insert into core.StationAccessControl(StationId,QualificationId,State,AccessLevel,EditDateTime,EditorId) values(@i,@j,1,NULL,getdate(),2)
	set @i = @i + 1
	set @j = @j + 1
END COMMIT TRANSACTION; END
go

