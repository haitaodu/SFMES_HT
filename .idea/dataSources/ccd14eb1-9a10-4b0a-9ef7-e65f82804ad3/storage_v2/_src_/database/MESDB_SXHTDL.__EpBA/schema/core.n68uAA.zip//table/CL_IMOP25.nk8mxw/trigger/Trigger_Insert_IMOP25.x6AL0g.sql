-- =============================================
-- Author:	SHILIN	<Author,,Name>
-- Create date: 2020-8-6 <Create Date,,>
-- Description:IMOP25 清洗机过站记录保存（此站没有不良品）	<Description,,>
-- =============================================
--Insert 触发器
CREATE TRIGGER [core].[Trigger_Insert_IMOP25]
   ON  [core].[CL_IMOP25]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @PNID int
	Declare @LastStationId int  --最后一站
	Declare @StationId int  --当前站
	Declare @WOderStartTime dateTime --工单开始时间
	Declare @CurrentTime varchar(30)
	Declare @WorkOrderId bigint

    --获取工单信息
	select top 1  @WorkOrderId=[WorkOrderId],@WOderStartTime=wo.ActualStartDateTime
	from [core].[CurrentActivedWorkOrderInformation] awo
	left join core.WorkOrder wo on awo.WorkOrderId=wo.Id

	--最后一站记录
	select @LastStationId=Id from core.Station where  StationNumber='IM_OP20'
	--获取当前工站Id
	select @StationId=Id from core.Station where  StationNumber='IM_OP25'

	--找到过了OP20没有过OP25站的产品并插入到过站记录中
	insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
	select top 1 998 [ProcessStepId],a.Id PartSerialNumberId,0 ProcessState,@StationId StationId,0 Layer,GETDATE() ProductionDateTime,GETDATE() BookDateTime,1 CycleTime
	from (select sn.Id,sn.SerialNumber,sn.CreationDateTime from core.PartSerialNumber sn 
	left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@LastStationId) a 
	where a.Id not in (select sn.Id from core.PartSerialNumber sn 
	left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@StationId) 
	order by a.CreationDateTime asc
	
END
go

