-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	钎焊炉TU_OP40<Description,,>
-- =============================================
--Insert 触发器
CREATE TRIGGER [core].[Trigger_Insert_TUOP40]
   ON  [core].[CL_TUOP40]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @PNID int
	Declare @LastStationId int  --最后一站
	Declare @StationId int  --当前站
	Declare @WOderStartTime dateTime --工单开始时间
	Declare @SerialNumberId bigint set @SerialNumberId=0
	Declare @MaterialId int
	Declare @ProcessId int
	Declare @Secquence int

    --获取工单信息
	select top 1  @WOderStartTime=wo.ActualStartDateTime
	from [core].[CurrentActivedWorkOrderInformation] awo
	left join core.WorkOrder wo on awo.WorkOrderId=wo.Id

	--最后一站记录
	--select @LastStationId=Id from core.Station where  StationNumber='TU_OP30'
	--获取当前工站Id
	select @StationId=Id from core.Station where  StationNumber='TU_OP40'

	--通过工艺找到最后一站
	if(@MaterialId<>0 and @StationId<>0)
	begin
	   --找到本站工艺,工序顺序号
	   select @Secquence=c.Secquence,@ProcessId=c.ProcessId from
	   (select  ps.Id,ps.ProcessId,ps.StationGroupId,ps.Secquence,ssg.StationtId from core.ProcessStep ps  join 
	   (select top 1 Id from core.Process p where p.MaterialId=@MaterialId and p.State<>-1 and p.ProcessNumber like'%TU') a
	   on ps.ProcessId=a.Id left join core.Station_StationGroup ssg on ps.StationGroupId=ssg.StationGroupId where ssg.StationtId=@StationId) c

	   --最后一站工站记录
	   select @LastStationId=ssg.StationtId from [core].[Station_StationGroup] ssg join
	   (select top 1 p.StationGroupId,p.Secquence from [core].[ProcessStep] p where ProcessId=@ProcessId and Secquence<@Secquence order by Secquence desc) a
	   on ssg.StationGroupId=a.StationGroupId
	   
	end

	if(@LastStationId<>0 and @StationId<>0 and @WOderStartTime is not null)
	begin
		--获取SN号
		select top 1 @SerialNumberId=a.Id 
		from (select sn.Id,sn.SerialNumber,sn.CreationDateTime from core.PartSerialNumber sn 
		left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
		where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@LastStationId and sn.State>-2) a 
		where a.Id not in (select sn.Id from core.PartSerialNumber sn 
		left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
		where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@StationId and sn.State>-2)
		order by a.CreationDateTime asc
	end

	--判断添加过站记录或异常信息
	if ( @SerialNumberId<>0)
	begin
		--找到过了OP30没有过OP40站的产品并插入到过站记录中
		insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
		values(1121,@SerialNumberId,0,@StationId,0,GETDATE(),GETDATE(),0)
	end
END
go

