CREATE VIEW [wms].[V_StockReport]
AS
SELECT   e.FactoryCode, e.Name AS FactoryName, c.AreaNumber, c.Description AS AreaName, d.MaterialNumber, 
                d.Description AS MaterialName, SUM(a.Quantity) AS TotalQuantity, COUNT(a.ContainerNumber) 
                AS TotalContainerQuantity
FROM      core.Container AS a INNER JOIN
                core.Location AS b ON a.CurrentLocationId = b.Id INNER JOIN
                core.Area AS c ON b.AreaId = c.Id INNER JOIN
                core.Material AS d ON d.Id = a.MaterialId INNER JOIN
                core.Factory AS e ON e.Id = c.FactoryId
WHERE   (c.AreaType > 0) AND (d.State = 1) AND (a.Quantity > 0) AND (c.State = 1)
GROUP BY d.MaterialNumber, c.Description, c.AreaNumber, e.FactoryCode, d.Description, e.Name
go

