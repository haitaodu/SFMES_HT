-- =============================================
-- Author:	石霖	<Author,,Name>
-- Create date: <Create Date,,>
-- Description:CL_REOP80过站记录	<Description,,>
-- =============================================
CREATE TRIGGER [core].[Trigger_Insert_REOP80]
   ON  [core].[CL_REOP80]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @SerialNumberId int
	Declare @SerialNumber varchar(50)
	Declare @StationId int  --当前站

    --获取0P80的二维码
	Select top 1 @SerialNumber=[SerialNumber] From [core].[CL_REOP80] order by CREATE_DATE DESC

	--获取当前工站Id
	select @StationId=Id from core.Station where  StationNumber='RE_OP80'

	if(@SerialNumber is not null)
	begin
	  select top 1 @SerialNumberId=Id from core.PartSerialNumber where SerialNumber=@SerialNumber
	end

	if(@SerialNumberId<>0)
	begin
	  insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
	  values(1024,@SerialNumberId,0,@StationId,0,GETDATE(),GETDATE(),0)
	end

	END
go

