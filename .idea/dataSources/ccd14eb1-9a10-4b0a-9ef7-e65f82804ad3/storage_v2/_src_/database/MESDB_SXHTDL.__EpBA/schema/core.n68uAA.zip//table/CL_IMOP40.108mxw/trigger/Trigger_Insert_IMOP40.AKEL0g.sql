-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	钎焊炉TU_OP40<Description,,>
-- =============================================
--Insert 触发器
CREATE TRIGGER [core].[Trigger_Insert_IMOP40]
   ON  [core].[CL_IMOP40]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	Declare @PNID int
	Declare @LastStationId int  --最后一站
	Declare @StationId int  --当前站
	Declare @WOderStartTime dateTime --工单开始时间
	Declare @SerialNumberId bigint set @SerialNumberId=0

    --获取工单信息
	select top 1  @WOderStartTime=wo.ActualStartDateTime
	from [core].[CurrentActivedWorkOrderInformation] awo
	left join core.WorkOrder wo on awo.WorkOrderId=wo.Id

	--最后一站记录
	select @LastStationId=Id from core.Station where  StationNumber='IM_OP30'
	--获取当前工站Id
	select @StationId=Id from core.Station where  StationNumber='IM_OP40'

	--获取SN号
	select top 1 @SerialNumberId=a.Id 
	from (select sn.Id,sn.SerialNumber,sn.CreationDateTime from core.PartSerialNumber sn 
	left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@LastStationId) a 
	where a.Id not in (select sn.Id from core.PartSerialNumber sn 
	left join [trace].[PartProcessRecord] ppr on sn.Id=ppr.PartSerialNumberId
	where  sn.CreationDateTime>=@WOderStartTime and ppr.StationId=@StationId)
	order by a.CreationDateTime asc
	PRINT @SerialNumberId

	--判断添加过站记录或异常信息
	if ( @SerialNumberId<>0)
	begin
		--找到过了OP30没有过OP40站的产品并插入到过站记录中
		insert into [trace].[PartProcessRecord](ProcessStepId,PartSerialNumberId,ProcessState,StationId,Layer,ProductionDateTime,BookDateTime,CycleTime)
		values(1121,@SerialNumberId,0,@StationId,0,GETDATE(),GETDATE(),0)
	end
END
go

